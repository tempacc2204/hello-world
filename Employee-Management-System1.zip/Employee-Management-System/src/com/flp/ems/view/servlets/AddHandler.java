package com.flp.ems.view.servlets;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.service.IEmployeeService;
@WebServlet("/addHandler")
public class AddHandler extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("name");
		String phoneNumber=request.getParameter("phoneNumber");
		String dateOfBirth=request.getParameter("dateOfBirth");
		String dateOfJoining=request.getParameter("dateOfJoining");
		String address=request.getParameter("address");
		String departmentId=request.getParameter("departmentId");
		String projectId=request.getParameter("projectId");
		String roleId=request.getParameter("roleId");
		HashMap<String,String> map=new HashMap<String,String>();
		map.put("name",name);
		map.put("phoneNumber",phoneNumber);
		map.put("dateOfBirth",dateOfBirth);
		map.put("dateOfJoining", dateOfJoining);
		map.put("address",address);
		map.put("departmentId", departmentId);
		map.put("projectId",projectId);
		map.put("roleId",roleId);
		IEmployeeService employeeService=(IEmployeeService)getServletContext().getAttribute("employeeservice");
		employeeService.addEmployee(map);
		response.sendRedirect("index.jsp");
	}
}
