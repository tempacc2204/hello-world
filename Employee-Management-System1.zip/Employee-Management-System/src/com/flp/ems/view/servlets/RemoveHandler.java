package com.flp.ems.view.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.service.IEmployeeService;
@WebServlet("/removeHandler")
public class RemoveHandler extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
		IEmployeeService employeeService=(IEmployeeService)getServletContext().getAttribute("employeeservice");
		boolean success=employeeService.removeEmployee(id);
		request.setAttribute("success", success);
		String message;
		if(success){
			message="Employee deleted successfully";
		}
		else{
			message="Employee id not found in the system";
		}
		request.setAttribute("message",message);
		request.getRequestDispatcher("deleteresponse.jsp").forward(request, response);
	}
}
