package com.flp.ems.view.servlets;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.service.EmployeeServiceImpl;
import com.flp.ems.service.IEmployeeService;
@WebServlet("/initialaction")
public class StartServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IEmployeeService employeeService=new EmployeeServiceImpl();
		getServletContext().setAttribute("employeeservice", employeeService);
		String selectedOption=request.getParameter("action");
		System.out.println(selectedOption);
		switch(selectedOption){
			case "ADD_EMPLOYEE": request.getRequestDispatcher("add.jsp").forward(request, response);
								 break;
			case "MODIFY_EMPLOYEE": request.getRequestDispatcher("modify.jsp").forward(request, response);
			 					    break;
			case "REMOVE_EMPLOYEE": request.getRequestDispatcher("remove.jsp").forward(request, response);
			 					    break; 					 
			case "FIND_EMPLOYEE": request.getRequestDispatcher("find.jsp").forward(request, response);
			    					break; 					  	
			case "DISPLAY_ALL_EMPLOYEE": request.getRequestDispatcher("showAllHandler").forward(request, response);
			    					break;     					
		}
	}
}
